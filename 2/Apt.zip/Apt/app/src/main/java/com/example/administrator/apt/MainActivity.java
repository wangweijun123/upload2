package com.example.administrator.apt;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;


@Route(path = "aaaaa")
public class MainActivity extends AppCompatActivity {

    int i;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
