package com.dongnao.apt;

/**
 * @author Lance
 * @date 2018/3/22
 */

public class MainActivity_Binding {

    public MainActivity_Binding(MainActivity mainActivity) {
        mainActivity.tv = mainActivity.findViewById(R.id.tv);
    }
}
