package com.dongnao.compiler;

import com.google.auto.service.AutoService;
import com.squareup.javapoet.JavaFile;
import com.squareup.javapoet.MethodSpec;
import com.squareup.javapoet.TypeSpec;

import java.io.IOException;
import java.util.Set;

import javax.annotation.processing.AbstractProcessor;
import javax.annotation.processing.Filer;
import javax.annotation.processing.Messager;
import javax.annotation.processing.ProcessingEnvironment;
import javax.annotation.processing.Processor;
import javax.annotation.processing.RoundEnvironment;
import javax.annotation.processing.SupportedAnnotationTypes;
import javax.annotation.processing.SupportedSourceVersion;
import javax.lang.model.SourceVersion;
import javax.lang.model.element.Element;
import javax.lang.model.element.Modifier;
import javax.lang.model.element.TypeElement;

/**
 * @author Lance
 * @date 2018/3/22
 */

@AutoService(Processor.class)
//允许注解处理器处理的注解
@SupportedAnnotationTypes({"com.dongnao.annotation.BindView"})
@SupportedSourceVersion(SourceVersion.RELEASE_7)
public class TextProcessor extends AbstractProcessor {

    //日志工具
    Messager messager;
    //文件工具
    private Filer filer;

    @Override
    public synchronized void init(ProcessingEnvironment processingEnvironment) {
        super.init(processingEnvironment);
        messager = processingEnvironment.getMessager();
        filer = processingEnvironment.getFiler();
    }

    /**
     * @param set              使用了当前注解处理器允许处理注解的节点集合
     * @param roundEnvironment 环境
     * @return
     */
    @Override
    public boolean process(Set<? extends TypeElement> set, RoundEnvironment roundEnvironment) {
        for (TypeElement typeElement : set) {
            Set<? extends Element> elements = roundEnvironment
                    .getElementsAnnotatedWith(typeElement);
            for (Element element : elements) {
                /**
                 * 注解处理器也需要依赖注解模块这样就能通过下面函数获得注解，从而拿到value(id)
                 * element.getAnnotation();
                 */
                //获得父节点 MainActivity
                Element enclosingElement = element.getEnclosingElement();
                String className = enclosingElement.getSimpleName() + "_Binding";

//                String javaContent = "package com.dongnao.apt;\n" +
//                        "\n" +
//                        "/**\n" +
//                        " * @author Lance\n" +
//                        " * @date 2018/3/22\n" +
//                        " */\n" +
//                        "\n" +
//                        "public class MainActivity_Binding {\n" +
//                        "\n" +
//                        "    public MainActivity_Binding(MainActivity mainActivity) {\n" +
//                        "        mainActivity.tv = mainActivity.findViewById(R.id.tv);\n" +
//                        "    }\n" +
//                        "}\n";

                MethodSpec main = MethodSpec.methodBuilder("test")
                        .addModifiers(Modifier.PUBLIC, Modifier.STATIC)
                        .returns(void.class)
                        .addParameter(String[].class, "args")
                        .addStatement("$T.out.println($S)", System.class, "Hello, JavaPoet!")
                        .build();

                TypeSpec helloWorld = TypeSpec.classBuilder(className)
                        .addModifiers(Modifier.PUBLIC, Modifier.FINAL)
                        .addMethod(main)
                        .build();

                JavaFile javaFile = JavaFile.builder("com.example.helloworld", helloWorld)
                        .build();
                try {
                    javaFile.writeTo(filer);
                } catch (IOException e) {
                    e.printStackTrace();
                }

            }

        }

        return true;
    }
}
